==========================
Usage
==========================
 java -cp .;jvmon.jar;<JDK_HOME>\lib\tools.jar in.uglyhunk.jvm.mon.Main {q|[f|b]} [{frequency} {num_of_updates} {vmdesc1,vmdesc2,vmdesc3..} {vmscan_rate}]

where,
 q - list the running JVMs

 f - output only to file

 b - output to console and file

 frequency - metrics ready frequency

 num_of_updates - number of readings

 vmdesc1,vmdesc2,... - description of JVM(s) to scan for

 vmscan_rate - scan frequency for JVMs matching descriptions in arg4

Examples:

 1. Query JVMs running in the system
         java .;jvmon.jar;<JDK_HOME>\lib\tools.jar in.uglyhunk.jvm.mon.Main q

 2. Monitor all JVMs with description oracle.oats and jconsole every 15 seconds for an hour while scanning for new JVMs every minute
         java .;jvmon.jar;<JDK_HOME>\lib\tools.jar in.uglyhunk.jvm.mon.Main f 15 240 oracle.oats,jconsole 60
		
==========================		
Scripts
==========================
 Scripts are included in the jvmon directory for automated or scheduled execution of jvmon. Edit JDK_HOME, JVMON_DIR and arguments to
 reflect your environment and monitoring needs.

==========================
Special Usage
==========================
 To monitor JVM instances running as Windows services, use PsExec.exe utility to execute jvmon as system account. Download PsExec.exe from 
 http://technet.microsoft.com/en-us/sysinternals/bb897553 and just add "PsExec.exe -s" before jvmon execution command. Check "monJVMSvcs.cmd"
 and "queryJVMSvcs.cmd" in jvmon directory for usage information.
 
==========================
Field definitions
==========================
 proc_id	- process id of the JVM instance

 usd_hp		- represents the amount of "heap" memory currently used (in MB)
 
 com_hp		- represents the amount of "heap" memory (in MB) that is guaranteed to be available for use by the Java virtual machine. 
		  The amount may change over time (increase or decrease) and will always be greater than or equal to "used heap".
 
 usd_non-hp	- represents the amount of "non-heap" memory currently used (in MB)
 
 com_non-hp	- represents the amount of "non-heap" memory (in MB) that is guaranteed to be available for use by the Java virtual machine. 
		  The amount may change over time (increase or decrease) and will always be greater than or equal to "used non-heap".
 
 cur_ld_clas	- number of classes that are currently loaded in the Java virtual machine
 
 tot_ld_clas	- total number of classes that have been loaded since the Java virtual machine has started execution
 
 tot_uld_clas	- total number of classes unloaded since the Java virtual machine has started execution
 
 d_thd		- current number of live daemon threads
 
 pk_thd		- peak live thread count since the Java virtual machine started or peak was reset
 
 cur_thd	- current number of live threads including both daemon and non-daemon threads
 
 tot_std_thd	- total number of threads created and also started since the Java virtual machine started.
 

